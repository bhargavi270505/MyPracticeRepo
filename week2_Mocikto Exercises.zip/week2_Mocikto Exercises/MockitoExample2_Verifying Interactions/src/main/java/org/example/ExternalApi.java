package org.example;

public interface ExternalApi {
    String getData();  // This will be verified
}
