package com.library;

import org.springframework.stereotype.Component;

@Component
public class BookRepository {
    public void save(String bookName) {
        System.out.println("Book saved: " + bookName);
    }
}
