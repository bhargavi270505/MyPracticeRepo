package com.cognizant.spring_learn.service;

import com.cognizant.spring_learn.model.Country;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

import javax.xml.transform.stream.StreamSource;
import java.util.List;

@Service
public class CountryService {

    @Autowired
    private Jaxb2Marshaller marshaller;

    public Country getCountry(String code) {
        try {
            StreamSource source = new StreamSource(new ClassPathResource("country.xml").getInputStream());
            CountryList countries = (CountryList) marshaller.unmarshal(source);

            return countries.getCountryList().stream()
                    .filter(c -> c.getCode().equalsIgnoreCase(code))
                    .findFirst()
                    .orElse(null);
        } catch (Exception e) {
            throw new RuntimeException("Failed to load countries", e);
        }
    }
}
