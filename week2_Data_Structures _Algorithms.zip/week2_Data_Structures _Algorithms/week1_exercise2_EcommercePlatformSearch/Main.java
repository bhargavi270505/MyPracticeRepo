public class Main {
    public static void main(String[] args) {
        Product[] products = {
                new Product(102, "Mouse", "Electronics"),
                new Product(101, "Keyboard", "Electronics"),
                new Product(103, "Monitor", "Electronics"),
                new Product(104, "Chair", "Furniture"),
                new Product(105, "Desk", "Furniture")
        };
        int searchId = 104;
        Product result1 = LinearSearch.searchById(products, searchId);
        System.out.println("Linear Search Result:");
        System.out.println(result1 != null ? result1 : "Product not found");
        Product result2 = BinarySearch.searchById(products, searchId);
        System.out.println("Binary Search Result:");
        System.out.println(result2 != null ? result2 : "Product not found");
    }
}
