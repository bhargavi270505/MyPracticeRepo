public class Main {
    public static void main(String[] args) {
        double principal = 1000.0;
        double rate = 0.05;
        int years = 10;
        double futureValue = FinancialForecast.calculateFutureValue(principal, rate, years);
        System.out.println("Future Value (recursive): $" + futureValue);
        double[] memo = new double[years + 1];
        double futureValueMemo = FinancialForecast.calculateFutureValueMemo(principal, rate, years, memo);
        System.out.println("Future Value (memoized): $" + futureValueMemo);
    }
}
