SET SERVEROUTPUT ON;

BEGIN
    FOR cust IN (SELECT CustomerID, Name, DOB FROM Customers) LOOP
        -- Calculate age
        IF MONTHS_BETWEEN(SYSDATE, cust.DOB) / 12 > 60 THEN
            -- Apply discount
            UPDATE Loans
            SET InterestRate = InterestRate - 1
            WHERE CustomerID = cust.CustomerID;

            DBMS_OUTPUT.PUT_LINE('1% interest discount applied for Customer: ' || cust.Name);
        END IF;
    END LOOP;

    COMMIT;
END;
/
-- Run once before the PL/SQL block
ALTER TABLE Customers ADD IsVIP VARCHAR2(5);

SET SERVEROUTPUT ON;

BEGIN
    FOR cust IN (SELECT CustomerID, Name, Balance FROM Customers) LOOP
        IF cust.Balance > 10000 THEN
            UPDATE Customers
            SET IsVIP = 'TRUE'
            WHERE CustomerID = cust.CustomerID;

            DBMS_OUTPUT.PUT_LINE('Customer ' || cust.Name || ' promoted to VIP.');
        ELSE
            UPDATE Customers
            SET IsVIP = 'FALSE'
            WHERE CustomerID = cust.CustomerID;
        END IF;
    END LOOP;

    COMMIT;
END;
/

SET SERVEROUTPUT ON;

BEGIN
    FOR loan IN (
        SELECT l.LoanID, l.CustomerID, l.EndDate, c.Name
        FROM Loans l
        JOIN Customers c ON l.CustomerID = c.CustomerID
        WHERE l.EndDate BETWEEN SYSDATE AND SYSDATE + 30
    ) LOOP
        DBMS_OUTPUT.PUT_LINE('Reminder: Loan ID ' || loan.LoanID ||
                             ' for customer ' || loan.Name ||
                             ' is due on ' || TO_CHAR(loan.EndDate, 'DD-Mon-YYYY'));
    END LOOP;
END;
/
