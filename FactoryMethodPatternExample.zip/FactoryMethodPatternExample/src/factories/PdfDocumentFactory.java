package factories;
import documents.Document;
import documents.PdfDocumentImp;
public class PdfDocumentFactory extends DocumentFactory {
    @Override
    public Document createDocument() {
        return new PdfDocumentImp();
    }

}
