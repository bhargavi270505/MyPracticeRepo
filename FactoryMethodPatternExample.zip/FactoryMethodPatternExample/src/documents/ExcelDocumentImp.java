package documents;

public class ExcelDocumentImp implements Document {
    @Override
    public void open(){
        System.out.println("Opening a excel document.");
    }
}
