package documents;

public interface PdfDocument extends Document {
    @Override
    default void open() {
        System.out.println("Opening a PDF document.");
    }
}
