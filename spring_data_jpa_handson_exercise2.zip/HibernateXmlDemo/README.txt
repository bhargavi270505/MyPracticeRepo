Hibernate XML Configuration Demo
--------------------------------

Steps:
1. Make sure MySQL is running and a database named `hibernatedb` exists.
2. Set your MySQL username and password in hibernate.cfg.xml
3. Add Hibernate and MySQL JARs to the `lib/` folder and build path in your IDE.
4. Run MainApp.java

Features Demonstrated:
- session.save()
- session.createQuery().list()
- session.get()
- session.delete()
- transaction.beginTransaction(), commit(), rollback()
