package com.hibernate.demo;

import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.List;

public class MainApp {
    public static void main(String[] args) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;

        try {
            tx = session.beginTransaction();

            Employee emp1 = new Employee("Teja", "Shwini", 30000);
            session.save(emp1);

            List<Employee> employees = session.createQuery("FROM Employee").list();
            for (Employee emp : employees) {
                System.out.println(emp.getId() + ": " + emp.getFirstName() + " " + emp.getLastName() + " - " + emp.getSalary());
            }

            Employee emp = session.get(Employee.class, emp1.getId());
            if (emp != null) {
                session.delete(emp);
                System.out.println("Deleted employee with ID: " + emp.getId());
            }

            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
    }
}
