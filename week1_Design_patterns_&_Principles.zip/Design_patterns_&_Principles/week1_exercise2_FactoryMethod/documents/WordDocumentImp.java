package documents;

public class WordDocumentImp implements Document{
    @Override
    public void open(){
        System.out.println("Opening a word document.");
    }
}
