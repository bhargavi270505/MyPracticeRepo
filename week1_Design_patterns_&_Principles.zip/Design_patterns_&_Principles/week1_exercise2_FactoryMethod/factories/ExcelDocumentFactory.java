package factories;
import documents.Document;
import documents.ExcelDocumentImp;
public class ExcelDocumentFactory extends DocumentFactory{
    @Override
    public Document createDocument() {
        return new ExcelDocumentImp();
    }
}
