package documents;

public interface ExcelDocument extends Document {
    @Override
    default void open() {
        System.out.println("Opening an Excel document.");
    }
}
