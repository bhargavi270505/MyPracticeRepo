package documents;

public class PdfDocumentImp implements Document{
    @Override
    public void open(){
        System.out.println("Opening a pdf document.");
    }
}
