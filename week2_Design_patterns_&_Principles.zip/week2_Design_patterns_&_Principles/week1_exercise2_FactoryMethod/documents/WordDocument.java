package documents;

public interface WordDocument extends Document{
    @Override
    default void open() {
        System.out.println("Opening a Word document.");
    }
}
